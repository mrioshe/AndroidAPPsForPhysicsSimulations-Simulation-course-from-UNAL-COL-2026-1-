package com.curso_simulaciones.midecimanovenaapp.datos;

public class AlmacenDatosRAM {

    public static int tamanoLetraResolucionIncluida;

    public static String nombreImagen1 = "xxxx";
    public static String nombreImagen2 = "xxxx";
    public static boolean habilitar_boton_tres = false;

    public AlmacenDatosRAM() {

    }

}